---
company: "Intershala"
role: "Intershala Student Partner"
dateStart: "09/01/2020"
dateEnd: "11/30/2020"
---

- Facilitated the upskilling of college students through Internshala Training programs.
- Provided guidance and support to students in navigating the training platform.
- Organized workshops and events to promote skill development and career readiness.
- Collaborated with Internshala team to enhance the training experience for students.
- Fostered a supportive community for learning and professional growth among students.